#!/usr/bin/env python3
# =====================================================================
#  run.py  —  OPTIONAL local launcher for "4 Player Tic Tac Toe 3".
#
#  You do NOT need this. The game runs perfectly by just double-clicking
#  index.html (file:///). This script is only here for people who want a
#  tiny local web server so that score-saving (localStorage) is rock solid
#  in every browser.
#
#  Usage:
#     python run.py            # serves on http://localhost:8000 and opens it
#     python run.py 9000       # use a custom port
#
#  Everything stays 100% on your own machine. Nothing is uploaded anywhere.
# =====================================================================
import http.server
import socketserver
import webbrowser
import os
import sys
import threading

ROOT = os.path.dirname(os.path.abspath(__file__))


def pick_port():
    if len(sys.argv) > 1:
        try:
            return int(sys.argv[1])
        except ValueError:
            pass
    return 8000


class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=ROOT, **kwargs)

    # quiet, friendly logging
    def log_message(self, fmt, *args):
        sys.stdout.write("  [server] " + (fmt % args) + "\n")


class Server(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True


def main():
    port = pick_port()
    os.chdir(ROOT)
    url = "http://localhost:%d/index.html" % port

    with Server(("127.0.0.1", port), Handler) as httpd:
        print("=" * 60)
        print("  4 PLAYER TIC TAC TOE 3  —  local server")
        print("  Serving:", ROOT)
        print("  Open:   ", url)
        print("  Press Ctrl+C to stop.")
        print("=" * 60)
        threading.Timer(0.6, lambda: webbrowser.open(url)).start()
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\n  Bye!")


if __name__ == "__main__":
    main()
