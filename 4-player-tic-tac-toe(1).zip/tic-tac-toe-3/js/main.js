/* =====================================================================
   main.js — application orchestrator. Wires state, board, dimmer and UI
   together and drives the game flow.  Plain script (no modules) so the
   whole thing runs by double-clicking index.html (file:///).
   ===================================================================== */
(function (global) {
  "use strict";

  var S = global.TTT_STATE;
  var UI = global.TTT_UI;
  var BOARD = global.TTT_BOARD;
  var DIMMER = global.TTT_DIMMER;

  var settings, game;
  var lockBoard = false; // prevents clicks mid-animation / after finish

  function boot() {
    settings = S.loadSettings();

    BOARD.init({ onCellClick: handleMove });
    DIMMER.init({ onChange: handleBrightness });

    applyPerformanceFlags();
    DIMMER.set(settings.brightness);
    UI.syncSettings(settings);
    UI.updateReadouts(settings);
    UI.renderNames(settings, handleNameInput);

    bindControls();
    newGame(false);          // build a starting game (no round increment)
    UI.showScreen("screen-title");
  }

  // ---------------- game lifecycle ----------------
  function newGame(advanceRound) {
    if (advanceRound) settings.round += 1;
    persist();
    game = S.makeGame(settings);
    S.firstPlayer(game);
    lockBoard = false;
    BOARD.render(game);
    UI.setRound(settings.round);
    UI.renderScoreboard(game, settings);
    UI.renderTurn(game, settings);
  }

  function handleMove(idx) {
    if (lockBoard || game.finished) return;
    if (game.cells[idx] !== null) return;

    var playerId = game.current;
    game.cells[idx] = playerId;
    game.moves += 1;
    BOARD.place(idx, playerId);

    // win?
    var line = S.checkWin(game.cells, playerId);
    if (line) {
      game.finished = true;
      game.winnerId = playerId;
      game.winLine = line;
      lockBoard = true;
      var winner = playerById(playerId);
      BOARD.highlightWin(game, winner);
      settings.scores[playerId] = (settings.scores[playerId] || 0) + 1;
      persist();
      UI.renderScoreboard(game, settings);
      setTimeout(function () {
        UI.showResult({ type: "win", player: winner, name: settings.names[playerId], round: settings.round });
      }, 700);
      return;
    }

    // draw?
    if (S.isDraw(game.cells, settings.smartDraw)) {
      game.finished = true;
      lockBoard = true;
      settings.scores.draws = (settings.scores.draws || 0) + 1;
      persist();
      UI.renderScoreboard(game, settings);
      var full = game.cells.every(function (v) { return v !== null; });
      setTimeout(function () {
        UI.showResult({ type: "draw", reason: full ? "Board full — nobody got three in a row." : "No three in a row is possible anymore." });
      }, 450);
      return;
    }

    // next turn
    S.nextPlayer(game, settings.chaos);
    UI.renderTurn(game, settings);
    UI.renderScoreboard(game, settings);
  }

  function playerById(id) {
    for (var i = 0; i < game.players.length; i++) if (game.players[i].id === id) return game.players[i];
    return game.players[0];
  }

  // ---------------- settings handlers ----------------
  function handleBrightness(v) { settings.brightness = v; persist(); }

  function handleNameInput(id, value) {
    settings.names[id] = value;
    persist();
    if (game) { rebuildPlayerNames(); UI.renderScoreboard(game, settings); UI.renderTurn(game, settings); }
  }
  function rebuildPlayerNames() {
    game.players.forEach(function (p) { p.name = settings.names[p.id] || p.label; });
  }

  function setPlayerCount(n) {
    settings.playerCount = n;
    persist();
    UI.syncSettings(settings);
    UI.updateReadouts(settings);
    newGame(false); // re-deal with the new roster
  }

  function toggleSetting(key) {
    settings[key] = !settings[key];
    persist();
    UI.syncSettings(settings);
    UI.updateReadouts(settings);
    applyPerformanceFlags();
  }

  // potato mode forces hover off; hyper hover & potato both affect the board
  function applyPerformanceFlags() {
    document.body.classList.toggle("potato", !!settings.potato);
    var hoverOn = !settings.potato; // potato disables the hover board entirely
    BOARD.setHoverEnabled(hoverOn);
    BOARD.setHyper(!!settings.hyperHover && !settings.potato);
  }

  function persist() { S.saveSettings(settings); }

  // ---------------- control bindings ----------------
  function bindControls() {
    // title screen
    on("btn-start", function () { UI.showScreen("screen-game"); newGame(false); });
    on("btn-dimmer", function () { UI.showScreen("screen-dimmer"); });
    on("btn-names-title", function () { UI.openModal("modal-names"); });
    on("btn-settings-title", function () { UI.openModal("modal-settings"); });

    // dimmer screen
    on("btn-dimmer-close", function () { UI.showScreen("screen-title"); });

    // game header
    on("btn-title", function () { UI.showScreen("screen-title"); });
    on("btn-names", function () { UI.openModal("modal-names"); });
    on("btn-settings", function () { UI.openModal("modal-settings"); });
    on("btn-new-round", function () { UI.hideResult(); newGame(true); });
    on("btn-reset-scores", resetScores);

    // result overlay
    on("btn-result-next", function () { UI.hideResult(); newGame(true); });
    on("btn-result-title", function () { UI.hideResult(); UI.showScreen("screen-title"); });

    // close buttons inside modals
    Array.prototype.forEach.call(document.querySelectorAll("[data-close-modal]"), function (b) {
      b.addEventListener("click", function () { UI.closeModal(b.getAttribute("data-close-modal")); });
    });
    // click backdrop to close
    ["modal-names", "modal-settings"].forEach(function (id) {
      var ov = document.getElementById(id);
      ov.addEventListener("click", function (e) { if (e.target === ov) UI.closeModal(id); });
    });
    // ESC closes any open modal / leaves dimmer
    document.addEventListener("keydown", function (e) {
      if (e.key !== "Escape") return;
      UI.closeModal("modal-names");
      UI.closeModal("modal-settings");
      UI.hideResult();
    });

    // player count segmented control
    Array.prototype.forEach.call(document.querySelectorAll("#player-count .seg"), function (b) {
      b.addEventListener("click", function () { setPlayerCount(parseInt(b.getAttribute("data-count"), 10)); });
    });

    // toggles
    Array.prototype.forEach.call(document.querySelectorAll(".toggle[data-setting]"), function (t) {
      t.addEventListener("click", function () { toggleSetting(t.getAttribute("data-setting")); });
    });

    // generic 3D tilt for buttons marked .tilt-3d
    bindButtonTilt();

    // keep the win line correctly positioned on resize
    global.addEventListener("resize", function () {
      if (game && game.finished && game.winLine) {
        BOARD.highlightWin(game, playerById(game.winnerId));
      }
    });
  }

  function resetScores() {
    S.PLAYER_DEFS.forEach(function (p) { settings.scores[p.id] = 0; });
    settings.scores.draws = 0;
    settings.round = 1;
    persist();
    UI.setRound(settings.round);
    UI.renderScoreboard(game, settings);
  }

  function bindButtonTilt() {
    Array.prototype.forEach.call(document.querySelectorAll(".tilt-3d"), function (btn) {
      btn.addEventListener("pointermove", function (e) {
        if (document.body.classList.contains("potato")) return;
        var r = btn.getBoundingClientRect();
        var px = (e.clientX - r.left) / r.width - 0.5;
        var py = (e.clientY - r.top) / r.height - 0.5;
        btn.style.setProperty("--ry", (px * 14).toFixed(2) + "deg");
        btn.style.setProperty("--rx", (-py * 14).toFixed(2) + "deg");
      });
      btn.addEventListener("pointerleave", function () {
        btn.style.setProperty("--ry", "0deg");
        btn.style.setProperty("--rx", "0deg");
      });
    });
  }

  function on(id, fn) {
    var node = document.getElementById(id);
    if (node) node.addEventListener("click", fn);
  }

  // go!
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot);
  } else {
    boot();
  }
})(window);
