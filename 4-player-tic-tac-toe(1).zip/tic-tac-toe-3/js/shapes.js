/* =====================================================================
   shapes.js — every player mark is drawn with SVG geometry (no images).
   Exposes a global TTT_SHAPES helper used everywhere in the app.
   ===================================================================== */
(function (global) {
  "use strict";

  // Each shape returns an SVG string drawn inside a 0..100 viewBox.
  // Strokes are class-driven (see style.css) so colors stay in one place.
  function xMark() {
    return (
      '<svg viewBox="0 0 100 100" class="mark">' +
      '<line class="stroke" x1="24" y1="24" x2="76" y2="76"/>' +
      '<line class="stroke" x1="76" y1="24" x2="24" y2="76"/>' +
      "</svg>"
    );
  }

  function circleMark() {
    return (
      '<svg viewBox="0 0 100 100" class="mark">' +
      '<circle class="stroke" cx="50" cy="50" r="26"/>' +
      '<circle class="stroke" cx="50" cy="50" r="8"/>' +
      "</svg>"
    );
  }

  function triangleMark() {
    // upward triangle, rounded corners via stroke-linejoin
    return (
      '<svg viewBox="0 0 100 100" class="mark">' +
      '<polygon class="stroke" points="50,20 80,76 20,76"/>' +
      "</svg>"
    );
  }

  function squareMark() {
    return (
      '<svg viewBox="0 0 100 100" class="mark">' +
      '<rect class="stroke" x="24" y="24" width="52" height="52" rx="10"/>' +
      '<rect class="stroke" x="42" y="42" width="16" height="16" rx="4"/>' +
      "</svg>"
    );
  }

  var BUILDERS = {
    x: xMark,
    circle: circleMark,
    triangle: triangleMark,
    square: squareMark,
  };

  // Returns the inner SVG markup for a given shape id.
  function svg(id) {
    var fn = BUILDERS[id] || xMark;
    return fn();
  }

  // Build a wrapped <span class="shape s-xxx">…</span> ready for the board.
  function shapeNode(id) {
    var span = document.createElement("span");
    span.className = "shape s-" + id;
    span.innerHTML = svg(id);
    return span;
  }

  // A small badge version (for scoreboard / names / turn chip).
  function miniNode(id) {
    var span = document.createElement("span");
    span.className = "mini-shape s-" + id;
    span.innerHTML =
      '<svg viewBox="0 0 100 100"><rect class="badge stroke" x="6" y="6" width="88" height="88" rx="20" stroke-width="4"/>' +
      innerOnly(id) +
      "</svg>";
    return span;
  }

  // chip used in turn bar + result card
  function chipNode(id) {
    var span = document.createElement("span");
    span.className = "turn-chip s-" + id;
    span.innerHTML = svg(id);
    return span;
  }

  // Strip the outer <svg> wrapper so we can nest a mark inside a badge svg.
  function innerOnly(id) {
    var raw = svg(id);
    return raw.replace(/^<svg[^>]*>/, "").replace(/<\/svg>$/, "");
  }

  global.TTT_SHAPES = {
    ids: ["x", "circle", "triangle", "square"],
    svg: svg,
    shapeNode: shapeNode,
    miniNode: miniNode,
    chipNode: chipNode,
  };
})(window);
