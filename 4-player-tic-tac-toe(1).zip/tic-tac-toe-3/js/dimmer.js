/* =====================================================================
   dimmer.js — the "Light Switch Dimmer".
   A real-feeling slider that runs LIGHT -> GRAY -> DARK. The bulb inverts:
   it glows white on a dark background and turns black on a light one.
   ===================================================================== */
(function (global) {
  "use strict";

  var TTT_DIMMER = {};

  var track, knob, fill, bulb, halo, labels, body, themeColorMeta;
  var dragging = false;
  var value = 100; // 0 = full LIGHT, 100 = full DARK
  var onChange = null;

  function init(opts) {
    opts = opts || {};
    onChange = opts.onChange || null;
    body = document.body;
    track = document.getElementById("dimmer-track");
    knob = document.getElementById("dimmer-knob");
    fill = document.getElementById("dimmer-fill");
    bulb = document.getElementById("bulb");
    halo = document.getElementById("bulb-halo");
    labels = Array.prototype.slice.call(document.querySelectorAll(".dimmer-labels span"));
    themeColorMeta = document.querySelector('meta[name="theme-color"]');

    // Pointer drag on the knob
    knob.addEventListener("pointerdown", startDrag);
    // Click anywhere on the track to jump
    track.addEventListener("pointerdown", function (e) {
      if (e.target === knob) return;
      setFromPointer(e.clientX);
      startDrag(e);
    });
    global.addEventListener("pointermove", onMove);
    global.addEventListener("pointerup", endDrag);

    // Keyboard accessibility
    knob.addEventListener("keydown", function (e) {
      var step = e.shiftKey ? 10 : 4;
      if (e.key === "ArrowLeft" || e.key === "ArrowDown") { setValue(value - step); e.preventDefault(); }
      if (e.key === "ArrowRight" || e.key === "ArrowUp") { setValue(value + step); e.preventDefault(); }
      if (e.key === "Home") { setValue(0); e.preventDefault(); }
      if (e.key === "End") { setValue(100); e.preventDefault(); }
    });
  }

  function startDrag(e) { dragging = true; knob.setPointerCapture && knob.setPointerCapture(e.pointerId); }
  function endDrag() { dragging = false; }
  function onMove(e) { if (dragging) setFromPointer(e.clientX); }

  function setFromPointer(clientX) {
    var rect = track.getBoundingClientRect();
    var pct = ((clientX - rect.left) / rect.width) * 100;
    setValue(pct);
  }

  function setValue(v) {
    value = Math.max(0, Math.min(100, v));
    apply();
    if (onChange) onChange(Math.round(value));
  }

  // Map 0..100 -> background lightness & bulb appearance.
  function apply() {
    var v = value; // 0 light, 100 dark
    knob.style.left = v + "%";
    fill.style.width = v + "%";
    knob.setAttribute("aria-valuenow", String(Math.round(v)));

    // Background: blend from near-white (light) through gray to deep navy (dark)
    var t = v / 100;
    // Interpolate L*-ish lightness 96% -> 8%
    var lightness = 96 - t * 88;
    var bg = "hsl(225 28% " + lightness.toFixed(1) + "%)";
    body.style.background = bg;
    if (themeColorMeta) themeColorMeta.setAttribute("content", bg);

    // Theme class flips at the midpoint (the GRAY zone is the crossover)
    var isDark = v >= 50;
    body.classList.toggle("theme-dark", isDark);
    body.classList.toggle("theme-light", !isDark);

    // BULB INVERSION:
    //  - dark background -> bulb is bright/white and glows
    //  - light background -> bulb is black, no glow
    // glow intensity scales with how dark it is.
    var glow = Math.max(0, t - 0.1);
    var bulbVars = bulb.style;
    if (isDark) {
      bulbVars.setProperty("--bulb-fill", "#fff7e0");
      bulbVars.setProperty("--bulb-stroke", "#fff");
      bulbVars.setProperty("--bulb-glow", "rgba(255,236,170," + (0.35 + glow * 0.65).toFixed(2) + ")");
      halo.style.setProperty("--bulb-halo-op", (0.35 + glow).toFixed(2));
    } else {
      // pure black bulb on a light background
      bulbVars.setProperty("--bulb-fill", "#0c0f18");
      bulbVars.setProperty("--bulb-stroke", "#0c0f18");
      bulbVars.setProperty("--bulb-glow", "rgba(0,0,0,0)");
      halo.style.setProperty("--bulb-halo-op", "0");
    }

    // Active label highlight (zones: 0-33 light, 33-66 gray, 66-100 dark)
    var zone = v < 33 ? 0 : v < 66 ? 1 : 2;
    labels.forEach(function (el, i) { el.classList.toggle("active", i === zone); });
  }

  // public API
  TTT_DIMMER.init = init;
  TTT_DIMMER.set = setValue;
  TTT_DIMMER.get = function () { return Math.round(value); };
  TTT_DIMMER.refresh = apply;

  global.TTT_DIMMER = TTT_DIMMER;
})(window);
