/* =====================================================================
   ui.js — screens, modals, scoreboard, names, settings controls,
   the turn bar, the result overlay and confetti.
   ===================================================================== */
(function (global) {
  "use strict";

  var S = global.TTT_STATE;
  var SH = global.TTT_SHAPES;

  var UI = {};
  var el = function (id) { return document.getElementById(id); };

  // ---------------- screen navigation ----------------
  var SCREENS = ["screen-title", "screen-game", "screen-dimmer"];
  function showScreen(id) {
    SCREENS.forEach(function (s) {
      el(s).classList.toggle("is-active", s === id);
    });
  }

  // ---------------- modals ----------------
  function openModal(id) { el(id).classList.add("is-open"); }
  function closeModal(id) { el(id).classList.remove("is-open"); }

  // ---------------- scoreboard ----------------
  function renderScoreboard(game, settings) {
    var list = el("score-list");
    list.innerHTML = "";
    game.players.forEach(function (p) {
      var li = document.createElement("li");
      li.className = "score-row" + (game.current === p.id ? " is-turn" : "");
      li.style.setProperty("--row-color", p.cssColor);
      li.style.setProperty("--row-glow", p.cssGlow);
      li.appendChild(SH.miniNode(p.id));
      var name = document.createElement("span");
      name.className = "sr-name";
      name.textContent = settings.names[p.id] || p.label;
      var score = document.createElement("span");
      score.className = "sr-score";
      score.textContent = String(settings.scores[p.id] || 0);
      li.appendChild(name);
      li.appendChild(score);
      list.appendChild(li);
    });
    el("draws-count").textContent = String(settings.scores.draws || 0);
  }

  // ---------------- turn bar ----------------
  function renderTurn(game, settings) {
    var chipWrap = el("turn-chip");
    var text = el("turn-text");
    var info = el("turn-info");
    if (game.finished || !game.current) {
      chipWrap.innerHTML = "";
      text.textContent = "—";
      info.style.removeProperty("--turn-color");
      info.style.removeProperty("--turn-glow");
      return;
    }
    var p = findPlayer(game, game.current);
    chipWrap.innerHTML = "";
    chipWrap.appendChild(SH.chipNode(p.id));
    var nm = settings.names[p.id] || p.label;
    text.textContent = nm.toUpperCase() + "'S TURN";
    info.style.setProperty("--turn-color", p.cssColor);
    info.style.setProperty("--turn-glow", p.cssGlow);
  }

  function findPlayer(game, id) {
    for (var i = 0; i < game.players.length; i++) if (game.players[i].id === id) return game.players[i];
    return game.players[0];
  }

  function setRound(n) { el("round-num").textContent = String(n); }

  // ---------------- player names modal ----------------
  function renderNames(settings, onInput) {
    var wrap = el("names-list");
    wrap.innerHTML = "";
    S.PLAYER_DEFS.forEach(function (p) {
      var row = document.createElement("div");
      row.className = "name-row";
      row.style.setProperty("--row-color", p.cssColor);
      row.style.setProperty("--row-glow", p.cssGlow);
      row.appendChild(SH.miniNode(p.id));
      var input = document.createElement("input");
      input.className = "name-input";
      input.type = "text";
      input.maxLength = 16;
      input.value = settings.names[p.id] || p.label;
      input.setAttribute("aria-label", p.label + " player name");
      input.addEventListener("input", function () {
        var v = input.value.trim() || p.label;
        onInput(p.id, v);
      });
      row.appendChild(input);
      wrap.appendChild(row);
    });
  }

  // ---------------- settings controls sync ----------------
  function syncSettings(settings) {
    // player count segmented control
    Array.prototype.forEach.call(document.querySelectorAll("#player-count .seg"), function (b) {
      b.classList.toggle("is-on", parseInt(b.getAttribute("data-count"), 10) === settings.playerCount);
    });
    // toggles
    setToggle("t-chaos", settings.chaos);
    setToggle("t-hover", settings.hyperHover);
    setToggle("t-potato", settings.potato);
    setToggle("t-smartdraw", settings.smartDraw);
  }
  function setToggle(id, on) {
    var t = el(id);
    if (!t) return;
    t.classList.toggle("is-on", !!on);
    t.setAttribute("aria-checked", on ? "true" : "false");
  }

  // ---------------- readouts on title ----------------
  function updateReadouts(settings) {
    el("players-readout").textContent = settings.playerCount + " players";
    el("chaos-readout").textContent = settings.chaos ? "chaos turns" : "order randomized";
  }

  // ---------------- result overlay + confetti ----------------
  function showResult(opts) {
    var chip = el("result-chip");
    var title = el("result-title");
    var sub = el("result-sub");
    chip.innerHTML = "";
    if (opts.type === "win") {
      chip.appendChild(SH.chipNode(opts.player.id));
      chip.querySelector(".turn-chip").classList.add("s-" + opts.player.id);
      title.textContent = (opts.name || opts.player.label).toUpperCase() + " WINS!";
      sub.textContent = "Three in a row. Round " + opts.round + " complete.";
      burstConfetti(opts.player.cssColor);
    } else {
      title.textContent = "IT'S A DRAW";
      sub.textContent = opts.reason || "No three in a row possible.";
      var span = document.createElement("span");
      span.className = "turn-chip";
      span.innerHTML = '<svg viewBox="0 0 100 100"><line class="stroke" x1="22" y1="50" x2="78" y2="50" style="stroke:var(--text-dim);stroke-width:9;stroke-linecap:round"/></svg>';
      chip.appendChild(span);
      burstConfetti("#9aa3c0");
    }
    el("result-overlay").classList.add("is-open");
  }
  function hideResult() { el("result-overlay").classList.remove("is-open"); }

  // lightweight DOM confetti — no images, no libs
  function burstConfetti(color) {
    var host = el("confetti");
    host.innerHTML = "";
    if (document.body.classList.contains("potato")) return;
    var palette = [color, "#ffffff", "var(--c-x)", "var(--c-tri)", "var(--c-square)"];
    var count = 90;
    for (var i = 0; i < count; i++) {
      var bit = document.createElement("i");
      bit.style.left = Math.random() * 100 + "%";
      bit.style.background = palette[i % palette.length];
      bit.style.animationDuration = (1.6 + Math.random() * 1.8) + "s";
      bit.style.animationDelay = (Math.random() * 0.5) + "s";
      bit.style.transform = "rotate(" + Math.floor(Math.random() * 360) + "deg)";
      bit.style.width = (6 + Math.random() * 8) + "px";
      bit.style.height = (10 + Math.random() * 12) + "px";
      host.appendChild(bit);
    }
    setTimeout(function () { host.innerHTML = ""; }, 3600);
  }

  UI.showScreen = showScreen;
  UI.openModal = openModal;
  UI.closeModal = closeModal;
  UI.renderScoreboard = renderScoreboard;
  UI.renderTurn = renderTurn;
  UI.setRound = setRound;
  UI.renderNames = renderNames;
  UI.syncSettings = syncSettings;
  UI.updateReadouts = updateReadouts;
  UI.showResult = showResult;
  UI.hideResult = hideResult;

  global.TTT_UI = UI;
})(window);
