/* =====================================================================
   board.js — renders the 5x5 board, handles the hyper 3D hover tilt,
   places marks, and draws the animated winning line.
   ===================================================================== */
(function (global) {
  "use strict";

  var S = global.TTT_STATE;
  var SH = global.TTT_SHAPES;

  var boardEl, stageEl, lineLayer;
  var onCellClick = null;
  var hoverEnabled = true;
  var hyper = true;

  function init(opts) {
    opts = opts || {};
    boardEl = document.getElementById("board");
    stageEl = document.getElementById("board-stage");
    lineLayer = document.getElementById("win-line-layer");
    onCellClick = opts.onCellClick || null;

    buildCells();
    bindTilt();
  }

  // Create 25 cells once; we reuse them every round.
  function buildCells() {
    boardEl.innerHTML = "";
    for (var i = 0; i < S.SIZE * S.SIZE; i++) {
      var r = Math.floor(i / S.SIZE);
      var c = i % S.SIZE;
      var cell = document.createElement("button");
      cell.type = "button";
      cell.className = "cell";
      cell.setAttribute("role", "gridcell");
      cell.setAttribute("data-index", String(i));
      cell.setAttribute("data-row", String(r));
      cell.setAttribute("data-col", String(c));
      cell.setAttribute("aria-label", "Row " + (r + 1) + " column " + (c + 1));
      cell.addEventListener("click", cellClicked);
      boardEl.appendChild(cell);
    }
  }

  function cellClicked(e) {
    var idx = parseInt(e.currentTarget.getAttribute("data-index"), 10);
    if (onCellClick) onCellClick(idx, e.currentTarget);
  }

  // ---- hyper 3D hover -------------------------------------------------
  function bindTilt() {
    stageEl.addEventListener("pointermove", function (e) {
      if (!hoverEnabled) return;
      var rect = boardEl.getBoundingClientRect();
      var px = (e.clientX - rect.left) / rect.width - 0.5;
      var py = (e.clientY - rect.top) / rect.height - 0.5;
      var max = hyper ? 16 : 7;
      boardEl.style.setProperty("--bry", (px * max).toFixed(2) + "deg");
      boardEl.style.setProperty("--brx", (-py * max).toFixed(2) + "deg");
    });
    stageEl.addEventListener("pointerleave", resetTilt);
  }
  function resetTilt() {
    boardEl.style.setProperty("--bry", "0deg");
    boardEl.style.setProperty("--brx", "0deg");
  }

  function setHoverEnabled(on) { hoverEnabled = on; if (!on) resetTilt(); }
  function setHyper(on) { hyper = on; }

  // ---- render the whole board from a game object ----------------------
  function render(game) {
    var cells = boardEl.children;
    for (var i = 0; i < cells.length; i++) {
      var cell = cells[i];
      var val = game.cells[i];
      cell.classList.remove("win");
      cell.style.removeProperty("--win-c");
      cell.style.removeProperty("--win-g");
      if (val) {
        if (!cell.classList.contains("filled") || cell.getAttribute("data-mark") !== val) {
          cell.innerHTML = "";
          cell.appendChild(SH.shapeNode(val));
          cell.classList.add("filled");
          cell.setAttribute("data-mark", val);
        }
      } else {
        cell.innerHTML = "";
        cell.classList.remove("filled");
        cell.removeAttribute("data-mark");
      }
    }
    clearLine();
  }

  // place a single mark with the drop-in animation
  function place(idx, playerId) {
    var cell = boardEl.children[idx];
    cell.innerHTML = "";
    cell.appendChild(SH.shapeNode(playerId));
    cell.classList.add("filled");
    cell.setAttribute("data-mark", playerId);
  }

  // ---- winning line highlight + animated SVG stroke -------------------
  function highlightWin(game, player) {
    if (!game.winLine) return;
    var cssColor = player.cssColor;
    var cssGlow = player.cssGlow;
    game.winLine.forEach(function (i) {
      var cell = boardEl.children[i];
      cell.classList.add("win");
      cell.style.setProperty("--win-c", cssColor);
      cell.style.setProperty("--win-g", cssGlow);
    });
    drawLineThrough(game.winLine, cssColor);
  }

  // draw an SVG line through the centers of the winning cells (0..100 space)
  function drawLineThrough(indexes, color) {
    clearLine();
    var first = indexes[0];
    var last = indexes[indexes.length - 1];
    var a = cellCenterPct(first);
    var b = cellCenterPct(last);
    var ns = "http://www.w3.org/2000/svg";
    var line = document.createElementNS(ns, "line");
    line.setAttribute("x1", a.x); line.setAttribute("y1", a.y);
    line.setAttribute("x2", b.x); line.setAttribute("y2", b.y);
    line.setAttribute("stroke", color);
    line.style.color = color;
    lineLayer.appendChild(line);
  }

  // center of a cell as a percentage of the board grid (incl. padding)
  function cellCenterPct(idx) {
    var cell = boardEl.children[idx];
    var brect = boardEl.getBoundingClientRect();
    var crect = cell.getBoundingClientRect();
    var cx = crect.left + crect.width / 2 - brect.left;
    var cy = crect.top + crect.height / 2 - brect.top;
    return { x: (cx / brect.width) * 100, y: (cy / brect.height) * 100 };
  }

  function clearLine() { if (lineLayer) lineLayer.innerHTML = ""; }

  global.TTT_BOARD = {
    init: init,
    render: render,
    place: place,
    highlightWin: highlightWin,
    setHoverEnabled: setHoverEnabled,
    setHyper: setHyper,
    clearLine: clearLine,
  };
})(window);
