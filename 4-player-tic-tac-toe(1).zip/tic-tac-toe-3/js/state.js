/* =====================================================================
   state.js — game model, settings, persistence and the win / draw rules
   for a 5x5 board where 3-in-a-row wins.
   ===================================================================== */
(function (global) {
  "use strict";

  var SIZE = 5;       // 5x5 board
  var NEED = 3;       // 3 in a row to win
  var STORE_KEY = "ttt3_save_v1";

  // The four canonical players, in fixed identity order.
  var PLAYER_DEFS = [
    { id: "x",        label: "X",        name: "X",        cssColor: "var(--c-x)",      cssGlow: "var(--x-glow)" },
    { id: "circle",   label: "Circle",   name: "Circle",   cssColor: "var(--c-circle)", cssGlow: "var(--circle-glow)" },
    { id: "triangle", label: "Triangle", name: "Triangle", cssColor: "var(--c-tri)",    cssGlow: "var(--tri-glow)" },
    { id: "square",   label: "Square",   name: "Square",   cssColor: "var(--c-square)", cssGlow: "var(--square-glow)" },
  ];

  // -------- persisted settings (safe fallback if storage is blocked) ----
  var defaults = {
    playerCount: 4,
    chaos: true,        // pick next player randomly each move
    hyperHover: true,   // more tilt on the board
    potato: false,      // performance mode
    smartDraw: true,    // call a draw early when impossible to win
    brightness: 100,    // dimmer slider 0..100 (100 = full dark/neon)
    names: { x: "X", circle: "Circle", triangle: "Triangle", square: "Square" },
    scores: { x: 0, circle: 0, triangle: 0, square: 0, draws: 0 },
    round: 1,
  };

  var mem = null; // in-memory fallback object

  function loadSettings() {
    var saved = null;
    try {
      var raw = global.localStorage && localStorage.getItem(STORE_KEY);
      if (raw) saved = JSON.parse(raw);
    } catch (e) { /* file:// may block storage — ignore */ }
    var s = Object.assign({}, defaults, saved || {});
    s.names = Object.assign({}, defaults.names, (saved && saved.names) || {});
    s.scores = Object.assign({}, defaults.scores, (saved && saved.scores) || {});
    mem = s;
    return s;
  }

  function saveSettings(s) {
    mem = s;
    try {
      if (global.localStorage) localStorage.setItem(STORE_KEY, JSON.stringify(s));
    } catch (e) { /* ignore, keep in memory */ }
  }

  // -------- live game state -------------------------------------------
  function makeGame(settings) {
    var active = PLAYER_DEFS.slice(0, settings.playerCount).map(function (p) {
      return Object.assign({}, p, { name: settings.names[p.id] || p.name });
    });

    return {
      cells: new Array(SIZE * SIZE).fill(null), // each holds a player id or null
      players: active,
      order: shuffledOrder(active),             // randomized fair order
      turnIndex: 0,
      current: null,                            // set by start()
      moves: 0,
      finished: false,
      winnerId: null,
      winLine: null,                            // array of cell indexes
    };
  }

  function shuffledOrder(players) {
    var arr = players.map(function (p) { return p.id; });
    for (var i = arr.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1));
      var t = arr[i]; arr[i] = arr[j]; arr[j] = t;
    }
    return arr;
  }

  // -------- turn selection --------------------------------------------
  function firstPlayer(game) {
    game.turnIndex = 0;
    game.current = game.order[0];
    return game.current;
  }

  function nextPlayer(game, chaos) {
    if (chaos) {
      // pick a random player different from the current one (if possible)
      var pool = game.order.slice();
      if (pool.length > 1) {
        pool = pool.filter(function (id) { return id !== game.current; });
      }
      game.current = pool[Math.floor(Math.random() * pool.length)];
    } else {
      game.turnIndex = (game.turnIndex + 1) % game.order.length;
      game.current = game.order[game.turnIndex];
    }
    return game.current;
  }

  // -------- precompute every 3-in-a-row window on the 5x5 board --------
  var LINES = buildLines();
  function buildLines() {
    var lines = [];
    function idx(r, c) { return r * SIZE + c; }
    for (var r = 0; r < SIZE; r++) {
      for (var c = 0; c < SIZE; c++) {
        // horizontal
        if (c + NEED <= SIZE) lines.push([idx(r, c), idx(r, c + 1), idx(r, c + 2)]);
        // vertical
        if (r + NEED <= SIZE) lines.push([idx(r, c), idx(r + 1, c), idx(r + 2, c)]);
        // diagonal down-right
        if (r + NEED <= SIZE && c + NEED <= SIZE) lines.push([idx(r, c), idx(r + 1, c + 1), idx(r + 2, c + 2)]);
        // diagonal down-left
        if (r + NEED <= SIZE && c - (NEED - 1) >= 0) lines.push([idx(r, c), idx(r + 1, c - 1), idx(r + 2, c - 2)]);
      }
    }
    return lines;
  }

  // -------- win check: returns winning line indexes or null -----------
  function checkWin(cells, playerId) {
    for (var i = 0; i < LINES.length; i++) {
      var L = LINES[i];
      if (cells[L[0]] === playerId && cells[L[1]] === playerId && cells[L[2]] === playerId) {
        return L;
      }
    }
    return null;
  }

  // -------- draw detection --------------------------------------------
  // Hard draw: board full, no winner.
  // Smart draw: no remaining line can EVER be completed by a single player,
  // because every 3-window already contains two or more different marks.
  function isDraw(cells, smart) {
    var full = cells.every(function (v) { return v !== null; });
    if (full) return true;
    if (!smart) return false;

    for (var i = 0; i < LINES.length; i++) {
      var L = LINES[i];
      var seen = {};
      var distinct = 0;
      for (var k = 0; k < L.length; k++) {
        var v = cells[L[k]];
        if (v && !seen[v]) { seen[v] = 1; distinct++; }
      }
      // A line is still "live" if it contains at most one distinct player.
      if (distinct <= 1) return false;
    }
    return true; // every line is contested -> nobody can win
  }

  global.TTT_STATE = {
    SIZE: SIZE,
    NEED: NEED,
    PLAYER_DEFS: PLAYER_DEFS,
    loadSettings: loadSettings,
    saveSettings: saveSettings,
    makeGame: makeGame,
    firstPlayer: firstPlayer,
    nextPlayer: nextPlayer,
    checkWin: checkWin,
    isDraw: isDraw,
    shuffledOrder: shuffledOrder,
  };
})(window);
