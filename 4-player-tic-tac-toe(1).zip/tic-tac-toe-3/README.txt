========================================================================
 4 PLAYER TIC TAC TOE 3  —  5x5, 3-in-a-row, 3RDDD VERSION!!
========================================================================

HOW TO PLAY (the easy way)
--------------------------
1. Keep this whole folder together (do not split the files apart).
2. Double-click  index.html
3. That's it. It opens in your browser and runs 100% on your computer.
   Nothing goes to the internet. Fully local & private.

OPTIONAL (only if you want bullet-proof score saving)
-----------------------------------------------------
Some browsers limit saved data when you open a file directly. If you want
your scores/settings to always persist, run the tiny included launcher:

    python run.py

It starts a local-only server (http://localhost:8000) and opens the game.
Still 100% on your machine — it never leaves your laptop.

WHAT'S INSIDE
-------------
  index.html        the page
  css/style.css     all the neon/glass styling + animations (no images!)
  js/shapes.js      X / Circle / Triangle / Square drawn as SVG geometry
  js/state.js       players, settings, save/load, win & draw rules
  js/dimmer.js      the Light Switch Dimmer (light -> gray -> dark)
  js/board.js       5x5 board, 3D hover tilt, winning-line animation
  js/ui.js          screens, modals, scoreboard, results, confetti
  js/main.js        glues everything together
  run.py            optional local launcher (Python 3)

THE RULES
---------
* Board is 5x5. Get 3 of your shape in a row (any direction) to win.
* It can be a DRAW: either the board fills with no winner, or "Smart draw"
  decides early that nobody can possibly make 3 in a row anymore.
* 2, 3 or 4 players. Players are:
      X = blue,  Circle = red,  Triangle = yellow,  Square = green
* Turn order is randomized every round so it's fair.
* "Chaos next turn" makes the next player random after EVERY move.

THE EXTRAS
----------
* SETTINGS: player count, chaos turns, hyper 3D hover, POTATO MODE
  (turns off heavy effects + the hover board so weak PCs / fullscreen
  never glitch), and smart-draw detection.
* PLAYER NAMES: rename each shape so the turn banner says e.g. "ZOE'S TURN"
  instead of the default — no more confusion about who's who.
* LIGHT SWITCH DIMMER: a slider from LIGHT -> GRAY -> DARK. The bulb turns
  white & glows on a dark background, and turns black on a light one.

No images are used anywhere — every shape, the bulb and the board are
drawn with pure CSS/SVG geometry. Enjoy! :D
